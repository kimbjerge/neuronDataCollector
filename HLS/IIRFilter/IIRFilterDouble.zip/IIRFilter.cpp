#include "IIRFilter.h"
#include <systemc.h>

static int64_t bn[DATA_CHANNELS*NUM_TAPS];
static int64_t an[DATA_CHANNELS*NUM_TAPS];
static sigType xin[DATA_CHANNELS*NUM_TAPS];
static double yout[DATA_CHANNELS*NUM_TAPS];


// Clear delay line
void initIIR(void) {

	for (int16_t ch = 0; ch < DATA_CHANNELS; ch++)
		for (int16_t i = 0; i < NUM_TAPS;  i++) {
			xin[i + NUM_TAPS*ch] = INIT_VALUE;
			yout[i + NUM_TAPS*ch] = INIT_VALUE;
		}
}

/**
* @brief Processing IIR filtering for a specific channel
*
* @param int32_t results :          Pointer to the IIR output is stored
* @param int32_t sample : 			Input sample
* @param int32_t channel :          Channel number to perform filtering
*
* @retval int32_t : IIR filtered sample
*/
sigType IIR(sigType sample, int16_t channel)
{
	double ysum;
	int64_t x;
	int64_t y;
	int64_t b;
	int64_t a;
	double result;
	int16_t i;

	// Shift delay line
	IIR_label1:for (i = NUM_TAPS-1; i > 0; i--) {
		xin[i + NUM_TAPS*channel] = xin[i-1 + NUM_TAPS*channel];
		yout[i + NUM_TAPS*channel] = yout[i-1 + NUM_TAPS*channel];
	}

	// Insert new sample
	xin[NUM_TAPS*channel] = sample;
	// Insert zero for a0 coefficient
	yout[NUM_TAPS*channel] = 0;

	// Perform filtering
	ysum = 0;
	IIR_label2:for (i = 0; i < NUM_TAPS; i++) {
		x = xin[i + NUM_TAPS*channel];
		b = bn[i + NUM_TAPS*channel];
		ysum += b*x;
		y = yout[i + NUM_TAPS*channel];
		a = an[i + NUM_TAPS*channel];
		ysum -= a*y;
	}

	// Scale filter result and return
	//result = (ysum+0x400000) >> ALGO_BITS; // Round
	//result = ysum >> ALGO_BITS; // Truncate

	// Insert new result
	result = ysum/pow(2,ALGO_BITS);
	yout[NUM_TAPS*channel] = result;

	//printf("%d, %d\r\n", channel, result);
	return round(result);
}

/**
* @brief Processing IIR filtering for number DATA_CHANNELS
*
* @param int32_t results :          Pointer to the IIR output is stored
* @param int32_t samples : 			Pointer to the input sample array - 1D
* @param int32_t coeff :            Pointer to the input coefficients array - 1D
* @param int32_t operation :        Operation = 0-7 update coefficients, Operation > 7 filter
*
* @retval void : none
*/
void IIRFilter (sigType results[DATA_CHANNELS],
				sigType samples[DATA_CHANNELS],
				int64_t coeff[NUM_TAPS*2],
				int32_t operation)
{

    if (operation < DATA_CHANNELS)
    {  // Update b and a coefficients
    	for (int16_t i = 0; i < NUM_TAPS; i++) {
    		bn[i + NUM_TAPS*operation] = coeff[i];// First b coefficients (forward xn)
    		an[i + NUM_TAPS*operation] = coeff[i+NUM_TAPS]; // Second a coefficients (backward yn)
    	}
    }
    else
    {  // Processing EQ filter
		IIRFilter_label0:for (int16_t ch = 0; ch < DATA_CHANNELS; ch++) {
			results[ch] = IIR(samples[ch], ch);
		}
    }
}
