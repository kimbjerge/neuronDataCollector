load ('eq_impulse.dat');
h = eq_impulse(:,3);
%h = h/max(h);
x = eq_impulse(:,2);
%x = x/max(x);
plot(x);
hold on
plot(h);
figure,
freqz(h);

%%
fs = 30000;

% Notch filter
fp = 5000;  % Pole frequency 0.1*fs (forst�rkning)
rp = 0.1; % Pole radius

fn = 5000; % Zero frequency 0.2*fs (d�mpning)
rn = 1; % Zero radius

wp = 2*pi*fp/fs;
wn = 2*pi*fn/fs;

% Cofficients numerator 
b0 = 1;
b1 = -2*rn*cos(wn);
b2 = rn^2;
b = [b0 b1 b2];

% Coefficients denominator
a0 = 1;
a1 = -2*rp*cos(wp);
a2 = rp^2;
a = [a0 a1 a2];

fc1 = 300;
fc2 = 6000;
[b,a] = butter(6,[fc1/(fs/2) fc2/(fs/2)]);

freqz(b,a)
y1 = filter(b, a, x);
figure
subplot(2,1,1);
plot(20*log10(abs(fft(y1))))

y2 = IIRfilter(b, a, x, 47);
subplot(2,1,2);
plot(20*log10(abs(fft(y2))))

figure, plot(y1-y2);


%% SOS sections
[z,p,k] = butter(order, [fc1/(fs/2) fc2/(fs/2)]);
sos = zp2sos(z,p,k);
fvtool(sos,'Analysis','freq')